import React from "react";
import {
  SafeAreaView,
  Text,
  View,
  TextInput,
  FlatList,
  Button,
  StyleSheet,
} from "react-native";
import { AntDesign } from "@expo/vector-icons";

const categories = [
  { id: "1", name: "Exercise" },
  { id: "2", name: "Study" },
  { id: "3", name: "Code" },
  { id: "4", name: "Cook" },
  { id: "5", name: "Mobile App Development" },
  { id: "6", name: "Web Development" },
  { id: "7", name: "Read" },
  { id: "8", name: "Relax" },
];

const tasks = [
  {
    id: "1",
    title: "Mobile App",
    description: "Work on mobile app development",
  },
  {
    id: "2",
    title: "Web Development",
    description: "Develop the homepage page",
  },
  {
    id: "3",
    title: "Game Development",
    description: "Develop the landing page",
  },
  { id: "4", title: "Push Up", description: "Do 30 push-ups" },
];

const Category = ({ name }) => (
  <View style={styles.category}>
    <Text style={styles.categoryText}>{name}</Text>
  </View>
);

const Task = ({ title, description }) => (
  <View style={styles.task}>
    <Text style={styles.taskTitle}>{title}</Text>
    <Text style={styles.taskDescription}>{description}</Text>
  </View>
);

const HomeScreen = () => {
  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.greetingContainer}>
        <Text style={styles.greetingText}>Hello, Devs</Text>
        <Text style={[styles.greetingText, { marginTop: 5, fontSize: 12 }]}>
          14 tasks today
        </Text>
      </View>

      {/* Search Bar */}
      <View style={[styles.searchBarContainer, { fontstyle: "Lato" }]}>
        <AntDesign
          name="search1"
          size={13}
          color="black"
          style={styles.searchIcon}
        />
        <TextInput style={styles.searchInput} placeholder="search" />
      </View>

      {/* Categories */}
      <Text style={styles.sectionTitle}>Categories</Text>
      <FlatList
        horizontal
        data={categories}
        renderItem={({ item }) => <Category name={item.name} />}
        keyExtractor={(item) => item.id}
        style={styles.categoriesContainer}
        showsHorizontalScrollIndicator={false}
      />

      {/* Ongoing Tasks */}
      <Text style={styles.sectionTitle}>Ongoing Tasks</Text>
      <FlatList
        data={tasks}
        renderItem={({ item }) => (
          <Task title={item.title} description={item.description} />
        )}
        keyExtractor={(item) => item.id}
        style={styles.tasksContainer}
        showsVerticalScrollIndicator={false}
      />

      {/* Add Task */}
      <TextInput style={styles.input} placeholder="Add a new task" />
      <Button title="Add Task" onPress={() => {}} />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: "column",
    justifyContent: "flex-start",
    backgroundColor: "#fff",
    padding: 16,
  },
  greetingContainer: {
    alignItems: "flex-start",
    marginTop: 52,
    marginLeft: 20,
    marginRight: 20,
  },
  greetingText: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#000000",
  },
  searchBarContainer: {
    flexDirection: "row",
    alignItems: "center",
    borderWidth: 1,
    margin: 10,
    padding: 10,
    borderColor: "#FBF9F7",
    borderRadius: 7,
    marginTop: 10,
  },
  searchIcon: {
    marginRight: 10,
  },
  searchInput: {
    fontSize: 17,
    flex: 1,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: "bold",
    marginVertical: 8,
  },
  categoriesContainer: {
    marginBottom: 16,
  },
  category: {
    padding: 12,
    backgroundColor: "#eee",
    borderRadius: 8,
    marginRight: 8,
  },
  categoryText: {
    fontSize: 16,
  },
  tasksContainer: {
    marginBottom: 16,
  },
  task: {
    padding: 16,
    backgroundColor: "#fff",
    borderRadius: 8,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: "#ddd",
  },
  taskTitle: {
    fontSize: 18,
    fontWeight: "bold",
  },
  taskDescription: {
    fontSize: 14,
    color: "#666",
  },
  input: {
    padding: 12,
    borderColor: "#ccc",
    borderWidth: 1,
    borderRadius: 8,
    marginBottom: 16,
  },
});

export default HomeScreen;
